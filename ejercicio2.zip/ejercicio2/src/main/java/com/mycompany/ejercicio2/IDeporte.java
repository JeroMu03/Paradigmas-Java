/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio2;

import java.util.List;

/**
 *
 * @author jero
 */
public interface IDeporte {
    public static final int cnt_minima=2;
    void mostrar();
    void numerarDeportista();
    boolean conformar(List<Deportista> integrantes);
}