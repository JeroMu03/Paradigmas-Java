/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio2;

/**
 *
 * @author jero
 */
public class Deportista {
    String nom;
    String dni;
    int numeroJugador;
    
    public Deportista(String nom, String dni) {
        this.nom = nom;
        this.dni = dni;
    }
    
    public String getNom() {
        return nom;
    }

    public String getDni() {
        return dni;
    }

    public int getNumeroJugador() {
        return numeroJugador;
    }
    
}
